# Agile

Agile contains hands-on trainings and projects.

- [Agile Session Class-notes](./class-notes/README.md)