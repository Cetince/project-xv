# Python Workshop

Python Workshop contains hands-on trainings and projects.

- [List of Python Hands-on Trainings](./hands-on/README.md)

- [List of Pyrhon  Projects](./projects/README.md)

- [Python Session Class-notes](./class-notes/README.md)