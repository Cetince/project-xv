# Python Hands-on Trainings

List of hands-on trainings within python workshop as follows;