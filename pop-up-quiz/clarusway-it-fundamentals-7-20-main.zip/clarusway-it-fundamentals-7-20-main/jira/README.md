# JIRA

JIRA contains hands-on trainings and projects.

- [List of JIRA  Hands-on Trainings](./hands-on/README.md)

- [List of JIRA Projects](./projects/README.md)

- [JIRA Session Class-notes](./class-notes/README.md)