# Git/Github Workshop

Computer Fundamentals Workshop contains hands-on trainings and projects.

- [List of Git/Github  Hands-on Trainings](./hands-on/README.md)

- [List of Git/Github  Projects](./projects/README.md)

- [Git/Github Session Class-notes](./class-notes/README.md)