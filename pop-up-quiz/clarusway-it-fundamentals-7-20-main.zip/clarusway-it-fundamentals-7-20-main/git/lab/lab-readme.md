# Git Lab

## Learning Goals


## Introduction

We'll clone **clarusway-it-fundamentals-7-20** to our computer and then we'll set up our remote repository. After that, we'll do some basic Git operations to a better understanding of basic commands.

## Instructions



