# SQL Projects

List of projects within SQL workshop as follows;
