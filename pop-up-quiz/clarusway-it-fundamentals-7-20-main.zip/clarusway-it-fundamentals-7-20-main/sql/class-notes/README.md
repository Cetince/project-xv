# SQL Session Class-notes

