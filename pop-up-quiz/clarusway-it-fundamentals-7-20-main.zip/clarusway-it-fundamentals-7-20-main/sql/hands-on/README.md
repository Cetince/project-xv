# SQL Hands-on Trainings

List of hands-on trainings within sql workshop as follows;