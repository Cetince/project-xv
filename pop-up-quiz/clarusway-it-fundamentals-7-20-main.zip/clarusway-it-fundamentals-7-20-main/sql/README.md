# SQL Workshop

SQL Workshop contains hands-on trainings and projects.

- [List of SQL  Hands-on Trainings](./hands-on/README.md)

- [List of SQL  Projects](./projects/README.md)

- [SQL Session Class-notes](./class-notes/README.md)