# Computer Fundamentals Workshop

Computer Fundamentals Workshop contains hands-on trainings and projects.

- [List of Computer Fundamentals  Hands-on Trainings](./hands-on/README.md)

- [List of Computer Fundamentals  Projects](./projects/README.md)

- [Computer Fundamentals Session Class-notes](./class-notes/README.md)