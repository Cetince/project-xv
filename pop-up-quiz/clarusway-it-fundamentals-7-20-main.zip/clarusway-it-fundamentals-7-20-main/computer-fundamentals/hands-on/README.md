# Computer Fundamentals Hands-on Trainings

List of hands-on trainings within computer fundamentals workshop as follows;