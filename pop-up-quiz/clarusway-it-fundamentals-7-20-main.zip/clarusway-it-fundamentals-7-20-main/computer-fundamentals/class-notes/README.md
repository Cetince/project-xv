# Computer Fundamentals Session Class-notes

