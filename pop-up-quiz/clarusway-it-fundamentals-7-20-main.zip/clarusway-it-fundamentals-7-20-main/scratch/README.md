# Scratch Workshop

Scratch Workshop contains hands-on trainings and projects.

- [List of Scratch Hands-on Trainings](./hands-on/README.md)

- [List of Scratch Projects](./projects/README.md)

- [Scratch Session Class-notes](./class-notes/README.md)