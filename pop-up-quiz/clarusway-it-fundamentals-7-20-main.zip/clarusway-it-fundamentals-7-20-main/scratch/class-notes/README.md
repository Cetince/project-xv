# Scratch Session Class-notes

