# Scratch Hands-on Trainings

List of hands-on trainings within scratch workshop as follows;