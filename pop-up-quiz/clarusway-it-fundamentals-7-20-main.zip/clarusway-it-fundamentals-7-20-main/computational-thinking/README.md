# Computational Thinking Workshop

Computer Fundamentals Workshop contains hands-on trainings and projects.

- [List of Computational Thinking  Hands-on Trainings](./hands-on/README.md)

- [List of Computational Thinking  Projects](./projects/README.md)

- [Computational ThinkingSession Class-notes](./class-notes/README.md)