# Computational Thinking Hands-on Trainings

List of hands-on trainings within Computational Thinking workshop as follows;