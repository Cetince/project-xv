# Computational Thinking Session Class-notes

