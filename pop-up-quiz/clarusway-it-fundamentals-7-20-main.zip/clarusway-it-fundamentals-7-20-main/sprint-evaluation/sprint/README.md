# Sprint Evaluation

## List of Sprint Evalution for ITFa Learning Path 

- [Sprint - 1 ](./sprint1/README.md)