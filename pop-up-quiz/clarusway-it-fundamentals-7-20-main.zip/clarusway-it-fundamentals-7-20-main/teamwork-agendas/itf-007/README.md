# ITF Teamwork Agendas


## List of teamwork agendas for ITF learning path

- [Teamwork Agenda - 001 ](./tw1/tw-001-team-lead.md)