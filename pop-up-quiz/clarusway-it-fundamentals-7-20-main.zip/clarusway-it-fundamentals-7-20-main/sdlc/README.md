# SDLC

SDLC contains hands-on trainings and projects.

- [SDLC Session Class-notes](./class-notes/README.md)